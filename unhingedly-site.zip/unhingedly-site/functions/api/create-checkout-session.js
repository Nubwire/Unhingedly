// Cloudflare Pages Function
// Route: POST /api/create-checkout-session
//
// Takes the cart from the front end, creates a real Stripe Checkout Session
// server-side (so the secret key never touches the browser), and returns the
// hosted checkout URL for the page to redirect to.
//
// Requires an environment variable/secret named STRIPE_SECRET_KEY, set in
// Cloudflare Pages → your project → Settings → Environment variables.

export async function onRequestPost(context) {
  const { request, env } = context;

  if (!env.STRIPE_SECRET_KEY) {
    return json({ error: "Stripe isn't configured yet — add STRIPE_SECRET_KEY in Cloudflare Pages settings." }, 500);
  }

  let body;
  try {
    body = await request.json();
  } catch (err) {
    return json({ error: "Invalid request body." }, 400);
  }

  const items = Array.isArray(body.items) ? body.items : [];
  const validItems = items.filter((item) => item && item.price);

  if (validItems.length === 0) {
    return json({ error: "Your cart doesn't have any valid Stripe price IDs yet — replace the price_REPLACE_ placeholders in index.html." }, 400);
  }

  const origin = request.headers.get('origin') || new URL(request.url).origin;

  const params = new URLSearchParams();
  params.append('mode', 'payment');
  params.append('success_url', `${origin}/?checkout=success`);
  params.append('cancel_url', `${origin}/?checkout=cancel`);

  validItems.forEach((item, i) => {
    params.append(`line_items[${i}][price]`, item.price);
    params.append(`line_items[${i}][quantity]`, String(item.quantity || 1));
  });

  let stripeRes;
  try {
    stripeRes = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${env.STRIPE_SECRET_KEY}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: params.toString(),
    });
  } catch (err) {
    return json({ error: "Couldn't reach Stripe. Try again in a moment." }, 502);
  }

  const session = await stripeRes.json();

  if (!stripeRes.ok) {
    return json({ error: session.error?.message || "Stripe rejected the request." }, 500);
  }

  return json({ url: session.url });
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}
