# Unhingedly

A single-page storefront site for Unhingedly — digital planners, templates, and
guides for ADHD brains. Static HTML/CSS/JS, no build step, no dependencies.

## Structure

```
.
├── index.html                            # the entire site (markup, styles, and script)
├── functions/
│   └── api/
│       └── create-checkout-session.js    # Cloudflare Pages Function — creates a Stripe Checkout Session
└── README.md
```

## Setting up Stripe checkout

Checkout is wired to real Stripe Checkout via a Cloudflare Pages Function
(`functions/api/create-checkout-session.js`). It runs server-side, so your
secret key never reaches the browser. To turn it on:

1. **Create a product + price in Stripe** for each item you sell (Stripe
   Dashboard → Product catalog → Add product). Each price has an ID that
   looks like `price_1AbCdEfGhIjK`.
2. **Paste those price IDs into `index.html`.** Every product `<article>` and
   the bundle box has a `data-price-id="price_REPLACE_..."` attribute —
   replace each placeholder with the real price ID from Stripe.
3. **Add your Stripe secret key to Cloudflare Pages:** in your Pages project,
   go to **Settings → Environment variables**, add a variable named
   `STRIPE_SECRET_KEY`, mark it as a **secret**, and set it for both
   Production and Preview. Use a `sk_test_...` key while testing, switch to
   `sk_live_...` when you're ready to take real payments.
4. **Redeploy.** Pages Functions in `/functions` are picked up automatically —
   no extra build config needed.

Test the flow with [Stripe's test card `4242 4242 4242 4242`](https://docs.stripe.com/testing)
(any future expiry, any CVC) before switching to live keys. After a
successful payment, Stripe redirects back to `/?checkout=success` and the
site clears the cart and shows a confirmation banner; a canceled checkout
redirects to `/?checkout=cancel` and leaves the cart untouched.

Digital delivery (emailing the actual files after purchase) isn't handled by
this function — that's typically done either by turning on **Stripe Checkout's
file/link delivery via a follow-up email tool**, or by adding a webhook that
fires when `checkout.session.completed` and sends the download links. Happy
to build that webhook next if you want automatic delivery.

## Local preview

No build tools needed. Either:

- Open `index.html` directly in a browser, or
- Serve it locally: `python3 -m http.server 8000` then visit `http://localhost:8000`

## Deploying with Cloudflare Pages (via GitHub)

1. Push this folder to a new GitHub repo (see commands below).
2. In the Cloudflare dashboard, go to **Workers & Pages → Create → Pages → Connect to Git**.
3. Select this repo.
4. Build settings:
   - **Framework preset:** None
   - **Build command:** *(leave blank)*
   - **Build output directory:** `/`
5. Click **Save and Deploy**. Cloudflare will build and give you a `*.pages.dev` URL, and you can attach a custom domain afterward under the project's **Custom domains** tab.

Every push to your default branch will auto-redeploy.

### Alternative: deploy straight from the CLI (no GitHub required)

If you ever want to skip GitHub entirely:

```
npx wrangler pages deploy . --project-name=unhingedly
```

## Pushing this repo to GitHub

This folder is already an initialized git repo with one commit. To push it:

```bash
git remote add origin https://github.com/<your-username>/<your-repo>.git
git branch -M main
git push -u origin main
```

(Create the empty repo on GitHub first — no README/license/gitignore — so there's
nothing to conflict with the initial commit.)

## Notes

- The cart (add/remove/subtotal) is a front-end convenience; checkout itself
  is real once you complete the Stripe setup above — clicking "Checkout"
  creates an actual Stripe Checkout Session and redirects there.
- Until you replace the `price_REPLACE_...` placeholders, checkout will show
  an inline error explaining what's missing instead of failing silently.
- Fonts (Space Grotesk, Inter, Caveat) load from Google Fonts via CDN link
  tags in `<head>` — no local font files to manage.
